import React, { useState } from 'react';
import CommentSection from './CommentSection';

const ImageViewer = ({ images }) => {
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  return (
    <div>
      <div  className='image-gallery' id="image-gallery">
        {images.map((image, index) => (
          <div key={index} className="image-container">
            <img
              src={URL.createObjectURL(image)}
              alt={`Uploaded ${index}`}
              onClick={() => handleImageSelect(image)}
            />
            {selectedImage === image && <CommentSection key={index} imageIndex={index} />}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImageViewer;
