import React, { useState, useEffect } from 'react';

import './CommentSections.css';

const CommentSection = ({ imageIndex }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
  
    const storedComments = JSON.parse(localStorage.getItem(`imageComments-${imageIndex}`)) || [];
    setComments(storedComments);
  }, [imageIndex]);

  const handleCommentChange = (event) => {
    setNewComment(event.target.value);
  };

  const handleCommentClick = (index) => {

    const updatedComments = [...comments];

    updatedComments.splice(index, 1);

    setComments(updatedComments);

    localStorage.setItem(`imageComments-${imageIndex}`, JSON.stringify(updatedComments));
  };

  const handleSubmit = () => {
    if (newComment.trim() !== '') {
      const updatedComments = [...comments, newComment];
      setComments(updatedComments);
      setNewComment('');

      localStorage.setItem(`imageComments-${imageIndex}`, JSON.stringify(updatedComments));
    }
  };

  return (
    <div className="comment-section">
      <h3>Comments</h3>
      <ul className="comments-list">
        {comments.map((comment, index) => (
          <li key={index} onClick={() => handleCommentClick(index)}>
            {comment}
          </li>
        ))}
      </ul>
      <div className="like-comment-section">
        <input
          type="text"
          className="comment-input"
          placeholder="Add a comment..."
          value={newComment}
          onChange={handleCommentChange}
        />
        <button className="post-comment-button" onClick={handleSubmit}>
          Post
        </button>
      </div>
    </div>
  );
};

export default CommentSection;
