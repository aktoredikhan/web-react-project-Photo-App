import React, { useState } from 'react';

const ImageUploader = ({ onImageUpload }) => {
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    setSelectedImage(file);
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      handleUpload();
    }
  };

  const handleUpload = () => {
    if (selectedImage) {
      onImageUpload(selectedImage);
      setSelectedImage(null);
    }
  };

  return (
    <div>
      <label htmlFor="images" className="drop-container" id="dropcontainer">
        <span className="drop-title">Drop files here</span>
        or
        <input
          type="file"
          accept="image/*"
          id="images"
          onChange={handleImageChange}
          onKeyDown={handleKeyDown}
        />
      </label>
    </div>
  );
};

export default ImageUploader;
