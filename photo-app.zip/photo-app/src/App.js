import React, { useState } from 'react';
import ImageUploader from './components/ImageUploader';
import ImageViewer from './components/ImageViewer';
import CommentSection from './components/CommentSection';

import './App.css'

const App = () => {
  const [images, setImages] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [comments, setComments] = useState([]);

  const handleImageUpload = (newImage) => {
    setImages([...images, newImage]);
  };

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  const handleCommentSubmit = (comment) => {
    setComments([...comments, comment]);
  };

  return (
    <div className='container'>
      <h1>Photo App</h1>
      <ImageUploader onImageUpload={handleImageUpload} />
      <ImageViewer images={images} onSelect={handleImageSelect} />
      {selectedImage && <CommentSection comments={comments} onCommentSubmit={handleCommentSubmit} />}
    </div>
  );
};

export default App;
